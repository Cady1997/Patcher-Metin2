namespace OctaneEngine.ShellProgressBar
{
    public enum ProgressBarHeight
    {
        Increment,
        Decrement
    }
}